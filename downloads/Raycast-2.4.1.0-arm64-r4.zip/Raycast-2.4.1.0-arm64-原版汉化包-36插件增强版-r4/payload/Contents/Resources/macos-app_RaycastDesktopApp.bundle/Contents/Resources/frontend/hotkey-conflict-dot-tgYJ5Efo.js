
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="fc5ac2d8-2e13-5317-a252-7e8d9c954b43")}catch(e){}}();
import{P as e}from"./icon-Dsm9xdX8.js";import{i as t}from"./visual-shortcut-BBcjC_lq.js";import{t as n}from"./simple-tooltip-t8OaZRFF.js";var r=e(),i={dot:`hotkey-conflict-dot__dot_3da76`};function a({commandId:e}){let{getConflictName:a}=t(),o=a(e);return o?(0,r.jsx)(n,{for:(0,r.jsx)(`span`,{className:i.dot,role:`img`,"aria-label":`快捷键与 ${o} 冲突`}),label:`也已分配给 ${o}`}):null}a.displayName=`HotkeyConflictDot`;export{a as t};
//# sourceMappingURL=hotkey-conflict-dot-tgYJ5Efo.js.map
//# debugId=fc5ac2d8-2e13-5317-a252-7e8d9c954b43
