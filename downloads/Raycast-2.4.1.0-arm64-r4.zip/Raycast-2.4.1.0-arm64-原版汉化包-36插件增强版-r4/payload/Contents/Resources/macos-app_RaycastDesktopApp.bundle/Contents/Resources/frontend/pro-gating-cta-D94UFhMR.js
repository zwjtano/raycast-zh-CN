
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="5e07628f-65b2-58de-9f10-6f988c59768a")}catch(e){}}();
function e(e){return!1}var t="如果你是 Raycast 新用户，",n="7 天 Pro 免费试用",r="会自动开始，无需信用卡。";function i(e){return e?.can_apply_for_free_trial??!0}function a(e){return i(e)?"开始免费试用":"升级到 Pro"}function o(e){return i(e)?"免费试用 Raycast Pro":"升级到 Raycast Pro"}function s(e,t){return`${i(e)?`Start a free trial`:`Upgrade to Pro`} to ${t}`}export{a,e as c,s as i,n,o,r,i as s,t};
//# sourceMappingURL=pro-gating-cta-D94UFhMR.js.map
//# debugId=5e07628f-65b2-58de-9f10-6f988c59768a
