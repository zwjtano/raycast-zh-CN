
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="f50b5fb0-fc9c-51d6-aca9-c076a171dfe7")}catch(e){}}();
import{n as e}from"./command-icons-QGzWhziQ.js";import{n as t}from"./settings-page-definition-utils-CpV8umQB.js";var n=t({description:"仅供开发使用的开关和内部调试设置。",group:`root`,icon:e.internal,id:`internal`,keywords:[`debug`,`developer`,`feature flags`,`internal`,`preload`,`worker`,`raycast api environment`],parent:`root`,path:`/internal`,rootSearchCommand:!0,title:"内部",alwaysShowNavigationTitle:!0,to:`/internal`,availability:`internal`});export{n as t};
//# sourceMappingURL=internal-settings-page-definition-DGJo7m6o.js.map
//# debugId=f50b5fb0-fc9c-51d6-aca9-c076a171dfe7
