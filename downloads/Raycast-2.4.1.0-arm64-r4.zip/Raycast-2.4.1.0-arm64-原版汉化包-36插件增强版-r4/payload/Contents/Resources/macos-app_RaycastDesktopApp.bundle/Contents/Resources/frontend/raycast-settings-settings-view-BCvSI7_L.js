
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="145d3f0d-46a8-5596-ab57-7b2d018a0c3d")}catch(e){}}();
import{P as e}from"./icon-Dsm9xdX8.js";import{A as t}from"./internal-extensions-CeYrcQb4.js";import{o as n}from"./settings-ui.namespace-JwCGEOQg.js";import{t as r}from"./extension-static-commands-yJ8zO7OD.js";var i=e();function a(){return(0,i.jsxs)(n,{extensionId:t.id,children:[(0,i.jsx)(r,{extensionId:t.id,commandsTitle:"设置",filter:`not-ai-extensions`}),(0,i.jsx)(r,{extensionId:t.id,commandsTitle:"AI 扩展",filter:`ai-extensions`})]})}a.displayName=`RaycastSettingsSettingsView`;export{a as RaycastSettingsSettingsView};
//# sourceMappingURL=raycast-settings-settings-view-BCvSI7_L.js.map
//# debugId=145d3f0d-46a8-5596-ab57-7b2d018a0c3d
