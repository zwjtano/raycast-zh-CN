
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="704e82f2-604f-5759-867e-7f4425ece077")}catch(e){}}();
import{T as e}from"./internal-extensions-CeYrcQb4.js";import{i as t,r as n,t as r}from"./settings-page-definition-utils-CpV8umQB.js";import{t as i}from"./settings-targets-BYmtc3dl.js";var a={scriptFolders:`script-folders`},o={rows:{scriptFolders:i({description:"这些文件夹中的脚本会被识别，并可作为命令使用。",id:a.scriptFolders,keywords:[`directories`,`folders`],title:"脚本文件夹"})}},s=r(e,{id:`script-commands`,keywords:[`directories`,`folders`,`script folders`,`scripts`],searchEntries:n([t(o.rows.scriptFolders,`row`,{search:{row:a.scriptFolders}})])});export{s as n,a as r,o as t};
//# sourceMappingURL=script-commands-settings-page-definition-6ETKn9Va.js.map
//# debugId=704e82f2-604f-5759-867e-7f4425ece077
