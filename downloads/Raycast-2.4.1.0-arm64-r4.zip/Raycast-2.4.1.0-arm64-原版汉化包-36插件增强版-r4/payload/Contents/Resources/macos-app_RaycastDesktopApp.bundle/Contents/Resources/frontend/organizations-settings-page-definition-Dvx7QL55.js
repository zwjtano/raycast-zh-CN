
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="e1e6cf35-3f4b-5356-bcda-4b054641559c")}catch(e){}}();
import{n as e}from"./command-icons-QGzWhziQ.js";import{n as t}from"./settings-page-definition-utils-CpV8umQB.js";var n=t({description:"管理组织、成员和组织设置。",group:`root`,icon:e.organizations,id:`organizations`,keywords:[`invite`,`members`,`organization`,`org`,`team`,`teams`,`webhooks`],parent:`root`,path:`/organizations`,rootSearchCommand:!0,title:"组织",to:`/organizations`});export{n as t};
//# sourceMappingURL=organizations-settings-page-definition-Dvx7QL55.js.map
//# debugId=e1e6cf35-3f4b-5356-bcda-4b054641559c
