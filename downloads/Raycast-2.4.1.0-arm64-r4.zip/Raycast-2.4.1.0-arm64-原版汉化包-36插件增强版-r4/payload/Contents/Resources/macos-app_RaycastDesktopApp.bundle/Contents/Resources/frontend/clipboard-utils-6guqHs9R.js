
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="3e4de4a2-4755-515e-90e8-9ed2e724f251")}catch(e){}}();
import{t as e}from"./services-CI1JjB8Y.js";import{n as t}from"./hud-store-BgPpts59.js";function n(e={}){let{title:n="已复制到剪贴板",message:r,icon:i=`copy-clipboard`}=e;t.open({variant:`success`,title:n,message:r,icon:i})}async function r({text:t,feedbackTitle:r,feedbackMessage:i,feedbackIcon:a}){await Promise.all([window.mainWindow?.close(),e.ipc.backend.clipboard.copy({text:t})]),n({title:r,message:i,icon:a})}export{n,r as t};
//# sourceMappingURL=clipboard-utils-6guqHs9R.js.map
//# debugId=3e4de4a2-4755-515e-90e8-9ed2e724f251
