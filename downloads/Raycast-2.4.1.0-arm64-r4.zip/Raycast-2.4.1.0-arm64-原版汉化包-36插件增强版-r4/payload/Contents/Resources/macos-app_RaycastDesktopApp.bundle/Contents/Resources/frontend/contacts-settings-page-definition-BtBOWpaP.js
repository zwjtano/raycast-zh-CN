
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="044938b7-ce83-5e5f-b55f-b8fd8901d7ce")}catch(e){}}();
import{tt as e}from"./internal-extensions-CeYrcQb4.js";import{i as t,r as n,t as r}from"./settings-page-definition-utils-CpV8umQB.js";import{t as i}from"./settings-targets-BYmtc3dl.js";var a={sortOrder:`sort-order`},o={rows:{sortOrder:i({description:"按名或姓排序联系人",id:a.sortOrder,keywords:[`sort`,`by`,`order`],title:"排序依据"})}},s=r(e,{id:`contacts`,keywords:[`contacts`],searchEntries:n([t(o.rows.sortOrder,`row`,{search:{row:a.sortOrder}})])});export{s as n,a as r,o as t};
//# sourceMappingURL=contacts-settings-page-definition-BtBOWpaP.js.map
//# debugId=044938b7-ce83-5e5f-b55f-b8fd8901d7ce
