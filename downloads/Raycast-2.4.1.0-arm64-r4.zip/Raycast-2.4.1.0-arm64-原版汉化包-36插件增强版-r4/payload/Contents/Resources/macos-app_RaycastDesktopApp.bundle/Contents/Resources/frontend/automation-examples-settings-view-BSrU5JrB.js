
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="62eea168-b606-5411-9f60-b9dff71fb220")}catch(e){}}();
import{P as e}from"./icon-Dsm9xdX8.js";import{t}from"./command-icons-QGzWhziQ.js";import{t as n}from"./automation-suggestions-COEPJYLm.js";import{t as r}from"./ai-settings-subpage-root-Z5ZL2R3E.js";import{r as i,t as a}from"./use-open-automation-suggestion-D8votHo6.js";var o=e();function s(){let e=a(`examples`);return(0,o.jsx)(r,{title:"自动化示例",description:n,icon:t.large.aiAutomation,children:(0,o.jsx)(i,{onSelect:e,showHeading:!1})})}s.displayName=`AutomationExamplesSettingsView`;export{s as AutomationExamplesSettingsView};
//# sourceMappingURL=automation-examples-settings-view-BSrU5JrB.js.map
//# debugId=62eea168-b606-5411-9f60-b9dff71fb220
