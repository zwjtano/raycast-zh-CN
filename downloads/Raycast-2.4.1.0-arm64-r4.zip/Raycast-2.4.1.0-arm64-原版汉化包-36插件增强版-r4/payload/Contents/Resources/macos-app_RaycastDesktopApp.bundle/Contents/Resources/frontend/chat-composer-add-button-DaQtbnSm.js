
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="29c5f548-3a56-5ee6-aa7b-3460de7abb0a")}catch(e){}}();
import{P as e}from"./icon-Dsm9xdX8.js";import{t}from"./shortcuts-CslcL67B.js";import{t as n}from"./simple-tooltip-t8OaZRFF.js";import{t as r}from"./chat-composer-control-button-B43e77Ti.js";var i=e(),a={button:`chat-composer-add-button__button_ca46d`},o=`plus-20`;function s({isOpen:e,onPointerDown:s,disabled:c,ref:l}){return(0,i.jsx)(n,{for:(0,i.jsx)(r,{ref:l,icon:o,size:`small`,className:a.button,"aria-label":"添加上下文","data-state":e?`open`:`closed`,onPointerDown:s,disabled:c}),label:"添加上下文",shortcut:t.toggleAboutPanel})}s.displayName=`ChatComposerAddButton`;export{s as t};
//# sourceMappingURL=chat-composer-add-button-DaQtbnSm.js.map
//# debugId=29c5f548-3a56-5ee6-aa7b-3460de7abb0a
