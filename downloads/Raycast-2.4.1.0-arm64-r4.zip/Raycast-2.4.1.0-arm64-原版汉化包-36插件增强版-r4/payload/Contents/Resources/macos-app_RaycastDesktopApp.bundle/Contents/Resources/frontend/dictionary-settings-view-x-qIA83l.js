
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="906c24a6-1222-5a17-9ea3-4b18bdbe4f81")}catch(e){}}();
import{P as e}from"./icon-Dsm9xdX8.js";import{J as t}from"./internal-extensions-CeYrcQb4.js";import{o as n}from"./settings-ui.namespace-JwCGEOQg.js";import{t as r}from"./extension-static-commands-yJ8zO7OD.js";var i=e();function a(){return(0,i.jsx)(n,{extensionId:t.id,children:(0,i.jsx)(r,{extensionId:t.id,commandsTitle:"词典"})})}a.displayName=`DictionarySettingsView`;export{a as DictionarySettingsView};
//# sourceMappingURL=dictionary-settings-view-x-qIA83l.js.map
//# debugId=906c24a6-1222-5a17-9ea3-4b18bdbe4f81
