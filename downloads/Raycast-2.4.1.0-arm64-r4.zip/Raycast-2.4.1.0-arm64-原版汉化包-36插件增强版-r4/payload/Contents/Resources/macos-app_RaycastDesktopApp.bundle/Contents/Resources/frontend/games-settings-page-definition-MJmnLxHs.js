
!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof globalThis?globalThis:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[n]="db1af26d-10a4-59cc-9b62-495140606c8f")}catch(e){}}();
import{U as e}from"./internal-extensions-CeYrcQb4.js";import{t}from"./settings-page-definition-utils-CpV8umQB.js";import{t as n}from"./settings-targets-BYmtc3dl.js";var r={gameMode:`game-mode`},i={rows:{gameMode:n({description:"检测到游戏窗口位于前台时，禁用 Raycast 快捷键。",id:r.gameMode,keywords:[`disable hotkeys`],title:"游戏模式"})}},a=t(e,{id:`games`,keywords:[`game mode`,`games`],searchEntries:[]});export{a as n,r,i as t};
//# sourceMappingURL=games-settings-page-definition-MJmnLxHs.js.map
//# debugId=db1af26d-10a4-59cc-9b62-495140606c8f
